package com.lumora.player

import android.app.Application
import android.content.Context
import android.graphics.drawable.BitmapDrawable
import android.util.Size as ASize
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.DataSource
import coil.fetch.DrawableResult
import coil.fetch.FetchResult
import coil.fetch.Fetcher
import coil.key.Keyer
import coil.request.Options

class LumoraApp : Application(), ImageLoaderFactory {
    override fun newImageLoader() = ImageLoader.Builder(this)
        .components { add(SongKeyer()); add(SongFetcher.Factory()) }
        .crossfade(true).build()
}

class SongKeyer : Keyer<Song> {
    override fun key(data: Song, options: Options) = "song_${data.id}"
}

/** Mengambil cover art dari file audio (embedded / album art) lewat MediaStore. */
class SongFetcher(private val ctx: Context, private val song: Song) : Fetcher {
    override suspend fun fetch(): FetchResult? = try {
        val bmp = ctx.contentResolver.loadThumbnail(song.uri, ASize(600, 600), null)
        DrawableResult(BitmapDrawable(ctx.resources, bmp), false, DataSource.DISK)
    } catch (e: Exception) { null }

    class Factory : Fetcher.Factory<Song> {
        override fun create(data: Song, options: Options, imageLoader: ImageLoader): Fetcher =
            SongFetcher(options.context, data)
    }
}
