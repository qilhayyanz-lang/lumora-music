package com.lumora.player

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

class MainActivity : ComponentActivity() {
    private val vm: PlayerViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { LumoraTheme { Root(vm) } }
    }
}

val Bg = Color(0xFF0D0B14)

@Composable
fun LumoraTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(
        primary = Color(0xFFB69CFF), onPrimary = Color(0xFF1B0B3F), secondary = Color(0xFF7FE3D1),
        background = Bg, surface = Color(0xFF15121F), surfaceVariant = Color(0xFF241F35),
        onSurface = Color(0xFFEDE9F7), onSurfaceVariant = Color(0xFFA9A3BD),
    ),
    content = content,
)
