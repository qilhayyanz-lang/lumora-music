package com.lumora.player

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

data class Song(
    val id: Long, val title: String, val artist: String, val album: String,
    val albumId: Long, val duration: Long, val uri: Uri, val dateAdded: Long,
)

object MusicRepository {
    suspend fun load(ctx: Context): List<Song> = withContext(Dispatchers.IO) {
        val out = mutableListOf<Song>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(
            MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.DATE_ADDED,
        )
        val sel = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 30000"
        ctx.contentResolver.query(collection, proj, sel, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                val artist = c.getString(2)?.takeIf { it != "<unknown>" } ?: "Artis tidak dikenal"
                out += Song(
                    id, c.getString(1) ?: "Tanpa judul", artist, c.getString(3) ?: "Album tidak dikenal",
                    c.getLong(4), c.getLong(5), ContentUris.withAppendedId(collection, id), c.getLong(6),
                )
            }
        }
        out
    }
}

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("lumora", Context.MODE_PRIVATE)

    fun favorites(): Set<Long> = sp.getStringSet("fav", emptySet())!!.mapNotNull { it.toLongOrNull() }.toSet()
    fun saveFavorites(s: Set<Long>) = sp.edit().putStringSet("fav", s.map { it.toString() }.toSet()).apply()

    fun playlists(): Map<String, List<Long>> {
        val o = JSONObject(sp.getString("playlists", "{}")!!)
        return o.keys().asSequence().associateWith { k ->
            val a = o.getJSONArray(k); List(a.length()) { a.getLong(it) }
        }
    }
    fun savePlaylists(m: Map<String, List<Long>>) {
        val o = JSONObject()
        m.forEach { (k, v) -> o.put(k, JSONArray(v)) }
        sp.edit().putString("playlists", o.toString()).apply()
    }
}
