@file:OptIn(ExperimentalMaterial3Api::class)

package com.lumora.player

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage

enum class SortBy(val label: String) { TITLE("Judul"), ARTIST("Artis"), RECENT("Terbaru"), LENGTH("Durasi") }

fun fmt(ms: Long): String { val s = (ms / 1000).coerceAtLeast(0); return "%d:%02d".format(s / 60, s % 60) }

@Composable
fun Root(vm: PlayerViewModel) {
    val ctx = LocalContext.current
    val perms = remember {
        buildList {
            if (Build.VERSION.SDK_INT >= 33) { add(Manifest.permission.READ_MEDIA_AUDIO); add(Manifest.permission.POST_NOTIFICATIONS) }
            else add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }
    fun granted() = ContextCompat.checkSelfPermission(ctx, perms.first()) == PackageManager.PERMISSION_GRANTED
    var ok by remember { mutableStateOf(granted()) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { ok = granted() }
    LaunchedEffect(ok) { if (ok) vm.loadSongs() }
    if (ok) MainScreen(vm) else Column(
        Modifier.fillMaxSize().background(Bg).padding(32.dp),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(Icons.Rounded.LibraryMusic, null, Modifier.size(72.dp), tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(16.dp))
        Text("Lumora", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Text("Izinkan akses ke file musik di perangkatmu untuk mulai.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(24.dp))
        Button(onClick = { launcher.launch(perms.toTypedArray()) }) { Text("Beri izin") }
    }
}

@Composable
fun Art(song: Song?, modifier: Modifier = Modifier, shape: Shape = RoundedCornerShape(12.dp)) {
    Box(
        modifier.clip(shape).background(Brush.linearGradient(listOf(Color(0xFF3A2A6B), Color(0xFF14323A)))),
        contentAlignment = Alignment.Center,
    ) {
        Icon(Icons.Rounded.MusicNote, null, tint = Color.White.copy(alpha = .5f))
        if (song != null) AsyncImage(song, null, Modifier.fillMaxSize(), contentScale = androidx.compose.ui.layout.ContentScale.Crop)
    }
}

@Composable
fun MainScreen(vm: PlayerViewModel) {
    val tabs = listOf("Lagu", "Album", "Artis", "Playlist", "Favorit")
    var tab by remember { mutableStateOf(0) }
    var query by remember { mutableStateOf("") }
    var searching by remember { mutableStateOf(false) }
    var sort by remember { mutableStateOf(SortBy.TITLE) }
    var sortMenu by remember { mutableStateOf(false) }
    var showNow by remember { mutableStateOf(false) }
    var detail by remember { mutableStateOf<Pair<String, String>?>(null) }
    var pickFor by remember { mutableStateOf<Song?>(null) }
    var newPlaylist by remember { mutableStateOf(false) }

    val base = remember(vm.songs, query, sort) {
        vm.songs.filter { query.isBlank() || listOf(it.title, it.artist, it.album).any { f -> f.contains(query, true) } }
            .let {
                when (sort) {
                    SortBy.TITLE -> it.sortedBy { s -> s.title.lowercase() }
                    SortBy.ARTIST -> it.sortedBy { s -> s.artist.lowercase() }
                    SortBy.RECENT -> it.sortedByDescending { s -> s.dateAdded }
                    SortBy.LENGTH -> it.sortedByDescending { s -> s.duration }
                }
            }
    }

    BackHandler(showNow) { showNow = false }
    BackHandler(detail != null && !showNow) { detail = null }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF1E1538), Bg, Bg)))) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(Modifier.padding(start = 20.dp, end = 8.dp, top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Lumora", Modifier.weight(1f), style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                IconButton({ searching = !searching; if (!searching) query = "" }) { Icon(Icons.Rounded.Search, "Cari") }
                Box {
                    IconButton({ sortMenu = true }) { Icon(Icons.Rounded.Sort, "Urutkan") }
                    DropdownMenu(sortMenu, { sortMenu = false }) {
                        SortBy.entries.forEach { s ->
                            DropdownMenuItem({ Text(s.label, color = if (s == sort) MaterialTheme.colorScheme.primary else Color.Unspecified) }, { sort = s; sortMenu = false })
                        }
                    }
                }
                IconButton({ vm.playShuffled(base); showNow = true }) { Icon(Icons.Rounded.Shuffle, "Acak semua") }
            }
            if (searching) TextField(
                query, { query = it }, Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                placeholder = { Text("Cari lagu, artis, album…") }, singleLine = true, shape = RoundedCornerShape(16.dp),
                colors = TextFieldDefaults.colors(focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent),
            )
            LazyRow(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(tabs.size) { i -> FilterChip(tab == i, { tab = i }, { Text(tabs[i]) }, shape = RoundedCornerShape(50)) }
            }
            Box(Modifier.weight(1f)) {
                when (tab) {
                    0 -> SongList(base, vm, onPick = { pickFor = it }, onPlay = { l, i -> vm.play(l, i) })
                    1 -> {
                        val albums = base.groupBy { it.albumId }.values.toList()
                        LazyVerticalGrid(GridCells.Fixed(2), contentPadding = PaddingValues(16.dp, 4.dp, 16.dp, 24.dp),
                            horizontalArrangement = Arrangement.spacedBy(14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                            items(albums) { l ->
                                Column(Modifier.clip(RoundedCornerShape(16.dp)).clickable { detail = "album" to l[0].albumId.toString() }) {
                                    Art(l[0], Modifier.fillMaxWidth().aspectRatio(1f), RoundedCornerShape(16.dp))
                                    Text(l[0].album, Modifier.padding(top = 6.dp), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                                    Text(l[0].artist, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                    2 -> LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
                        items(base.groupBy { it.artist }.toList().sortedBy { it.first.lowercase() }) { (name, l) ->
                            Row(Modifier.fillMaxWidth().clickable { detail = "artist" to name }.padding(16.dp, 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Art(l[0], Modifier.size(56.dp), CircleShape)
                                Spacer(Modifier.width(14.dp))
                                Column {
                                    Text(name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text("${l.size} lagu", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                    3 -> LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
                        item {
                            TextButton({ newPlaylist = true }, Modifier.padding(horizontal = 8.dp)) { Icon(Icons.Rounded.Add, null); Spacer(Modifier.width(6.dp)); Text("Buat playlist baru") }
                        }
                        items(vm.playlists.keys.toList()) { name ->
                            Row(Modifier.fillMaxWidth().clickable { detail = "playlist" to name }.padding(16.dp, 10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(56.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.LibraryMusic, null, tint = MaterialTheme.colorScheme.primary) }
                                Spacer(Modifier.width(14.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(name, fontWeight = FontWeight.SemiBold)
                                    Text("${vm.playlists[name]?.size ?: 0} lagu", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                IconButton({ vm.deletePlaylist(name) }) { Icon(Icons.Rounded.Delete, "Hapus") }
                            }
                        }
                    }
                    else -> SongList(base.filter { it.id in vm.favorites }, vm, onPick = { pickFor = it }, onPlay = { l, i -> vm.play(l, i) })
                }
            }
            vm.current?.let { MiniPlayer(vm) { showNow = true } }
            Spacer(Modifier.navigationBarsPadding())
        }

        AnimatedVisibility(detail != null, enter = slideInHorizontally { it }, exit = slideOutHorizontally { it }) {
            detail?.let { (type, key) ->
                val (title, list) = when (type) {
                    "album" -> vm.songs.filter { it.albumId.toString() == key }.let { (it.firstOrNull()?.album ?: "Album") to it }
                    "artist" -> key to vm.songs.filter { it.artist == key }
                    else -> key to (vm.playlists[key].orEmpty().mapNotNull { id -> vm.songs.firstOrNull { it.id == id } })
                }
                Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding()) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(end = 8.dp)) {
                        IconButton({ detail = null }) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Kembali") }
                        Text(title, Modifier.weight(1f), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        IconButton({ vm.playShuffled(list); showNow = true }) { Icon(Icons.Rounded.Shuffle, "Acak") }
                        FilledIconButton({ if (list.isNotEmpty()) { vm.play(list, 0); showNow = true } }) { Icon(Icons.Rounded.PlayArrow, "Putar") }
                    }
                    Box(Modifier.weight(1f)) {
                        SongList(list, vm, onPick = { pickFor = it }, onPlay = { l, i -> vm.play(l, i) },
                            onRemove = if (type == "playlist") ({ s: Song -> vm.removeFromPlaylist(key, s) }) else null)
                    }
                    vm.current?.let { MiniPlayer(vm) { showNow = true } }
                    Spacer(Modifier.navigationBarsPadding())
                }
            }
        }

        AnimatedVisibility(showNow && vm.current != null, enter = slideInVertically { it }, exit = slideOutVertically { it }) {
            NowPlaying(vm) { showNow = false }
        }
    }

    pickFor?.let { s -> PlaylistPicker(s, vm) { pickFor = null } }
    if (newPlaylist) NameDialog({ newPlaylist = false }) { vm.createPlaylist(it) }
}

@Composable
fun SongList(list: List<Song>, vm: PlayerViewModel, onPick: (Song) -> Unit, onPlay: (List<Song>, Int) -> Unit, onRemove: ((Song) -> Unit)? = null) {
    if (list.isEmpty()) Box(Modifier.fillMaxSize(), Alignment.Center) { Text("Belum ada lagu", color = MaterialTheme.colorScheme.onSurfaceVariant) }
    else LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
        items(list.size, key = { list[it].id }) { i ->
            val s = list[i]
            var menu by remember { mutableStateOf(false) }
            val cur = vm.current?.id == s.id
            Row(Modifier.fillMaxWidth().clickable { onPlay(list, i) }.padding(16.dp, 7.dp), verticalAlignment = Alignment.CenterVertically) {
                Art(s, Modifier.size(52.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, color = if (cur) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                    Text("${s.artist} • ${fmt(s.duration)}", maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (s.id in vm.favorites) Icon(Icons.Rounded.Favorite, null, Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                Box {
                    IconButton({ menu = true }) { Icon(Icons.Rounded.MoreVert, "Menu") }
                    DropdownMenu(menu, { menu = false }) {
                        DropdownMenuItem({ Text("Putar berikutnya") }, { menu = false; vm.playNext(s) })
                        DropdownMenuItem({ Text("Tambah ke antrean") }, { menu = false; vm.addToQueue(s) })
                        DropdownMenuItem({ Text(if (s.id in vm.favorites) "Hapus dari favorit" else "Tambah ke favorit") }, { menu = false; vm.toggleFav(s) })
                        DropdownMenuItem({ Text("Tambah ke playlist") }, { menu = false; onPick(s) })
                        if (onRemove != null) DropdownMenuItem({ Text("Hapus dari playlist") }, { menu = false; onRemove(s) })
                    }
                }
            }
        }
    }
}

@Composable
fun MiniPlayer(vm: PlayerViewModel, onOpen: () -> Unit) {
    val s = vm.current ?: return
    Surface(Modifier.fillMaxWidth().padding(12.dp, 6.dp).clip(RoundedCornerShape(22.dp)).clickable(onClick = onOpen),
        color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(22.dp)) {
        Column {
            Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Art(s, Modifier.size(46.dp), RoundedCornerShape(14.dp))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                    Text(s.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton({ vm.togglePlay() }) { Icon(if (vm.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, "Putar/Jeda") }
                IconButton({ vm.next() }) { Icon(Icons.Rounded.SkipNext, "Berikutnya") }
            }
            LinearProgressIndicator({ if (vm.duration > 0) vm.position.toFloat() / vm.duration else 0f }, Modifier.fillMaxWidth().height(2.dp))
        }
    }
}

@Composable
fun NameDialog(onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var t by remember { mutableStateOf("") }
    AlertDialog(onDismiss, title = { Text("Playlist baru") },
        text = { OutlinedTextField(t, { t = it }, singleLine = true, label = { Text("Nama playlist") }) },
        confirmButton = { TextButton({ onOk(t); onDismiss() }) { Text("Buat") } },
        dismissButton = { TextButton(onDismiss) { Text("Batal") } })
}

@Composable
fun PlaylistPicker(song: Song, vm: PlayerViewModel, onDismiss: () -> Unit) {
    var creating by remember { mutableStateOf(false) }
    if (creating) { NameDialog(onDismiss) { vm.createPlaylist(it, song) }; return }
    AlertDialog(onDismiss, title = { Text("Tambah ke playlist") },
        text = {
            Column {
                TextButton({ creating = true }) { Icon(Icons.Rounded.Add, null); Spacer(Modifier.width(6.dp)); Text("Playlist baru") }
                vm.playlists.keys.forEach { n -> TextButton({ vm.addToPlaylist(n, song); onDismiss() }) { Text(n) } }
            }
        },
        confirmButton = {}, dismissButton = { TextButton(onDismiss) { Text("Tutup") } })
}
