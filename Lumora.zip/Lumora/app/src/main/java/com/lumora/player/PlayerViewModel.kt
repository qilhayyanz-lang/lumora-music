package com.lumora.player

import android.app.Application
import android.content.ComponentName
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class PlayerViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = Prefs(app)
    private var controller: MediaController? = null
    private var byId = emptyMap<Long, Song>()
    private var sleepJob: Job? = null

    var songs by mutableStateOf<List<Song>>(emptyList()); private set
    var current by mutableStateOf<Song?>(null); private set
    var isPlaying by mutableStateOf(false); private set
    var position by mutableLongStateOf(0L); private set
    var duration by mutableLongStateOf(0L); private set
    var shuffle by mutableStateOf(false); private set
    var repeat by mutableIntStateOf(Player.REPEAT_MODE_OFF); private set
    var speed by mutableFloatStateOf(1f); private set
    var queue by mutableStateOf<List<Song>>(emptyList()); private set
    var favorites by mutableStateOf(prefs.favorites()); private set
    var playlists by mutableStateOf(prefs.playlists()); private set
    var sleepLeftMs by mutableLongStateOf(0L); private set

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) = sync(player)
    }

    init {
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val f = MediaController.Builder(app, token).buildAsync()
        f.addListener({
            controller = f.get().also { it.addListener(listener); sync(it) }
        }, MoreExecutors.directExecutor())
        viewModelScope.launch {
            while (true) {
                controller?.let { position = it.currentPosition; duration = it.duration.coerceAtLeast(0L) }
                delay(400)
            }
        }
    }

    private fun sync(p: Player) {
        current = byId[p.currentMediaItem?.mediaId?.toLongOrNull()]
        isPlaying = p.isPlaying
        shuffle = p.shuffleModeEnabled
        repeat = p.repeatMode
        speed = p.playbackParameters.speed
        queue = List(p.mediaItemCount) { p.getMediaItemAt(it).mediaId.toLongOrNull() }.mapNotNull { byId[it] }
    }

    fun loadSongs() = viewModelScope.launch {
        songs = MusicRepository.load(getApplication())
        byId = songs.associateBy { it.id }
        controller?.let { sync(it) }
    }

    private fun item(s: Song) = MediaItem.Builder()
        .setMediaId(s.id.toString()).setUri(s.uri)
        .setMediaMetadata(MediaMetadata.Builder().setTitle(s.title).setArtist(s.artist).setAlbumTitle(s.album).build())
        .build()

    fun play(list: List<Song>, index: Int) {
        val c = controller ?: return
        c.setMediaItems(list.map(::item), index, 0L); c.prepare(); c.play()
    }
    fun playShuffled(list: List<Song>) {
        if (list.isEmpty()) return
        controller?.shuffleModeEnabled = true
        play(list, list.indices.random())
    }
    fun playNext(s: Song) { val c = controller ?: return; if (c.mediaItemCount == 0) play(listOf(s), 0) else c.addMediaItem(c.currentMediaItemIndex + 1, item(s)) }
    fun addToQueue(s: Song) { val c = controller ?: return; if (c.mediaItemCount == 0) play(listOf(s), 0) else c.addMediaItem(item(s)) }
    fun skipTo(i: Int) { controller?.apply { seekToDefaultPosition(i); play() } }
    fun removeFromQueue(i: Int) { controller?.removeMediaItem(i) }

    fun togglePlay() { controller?.let { if (it.isPlaying) it.pause() else it.play() } }
    fun next() { controller?.seekToNext() }
    fun prev() { controller?.let { if (it.currentPosition > 3000) it.seekTo(0) else it.seekToPrevious() } }
    fun seekTo(ms: Long) { controller?.seekTo(ms) }
    fun toggleShuffle() { controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled } }
    fun cycleRepeat() {
        controller?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }
    fun setSpeed(s: Float) { controller?.setPlaybackSpeed(s) }

    fun setSleep(minutes: Int) {
        sleepJob?.cancel()
        if (minutes <= 0) { sleepLeftMs = 0; return }
        sleepLeftMs = minutes * 60_000L
        sleepJob = viewModelScope.launch {
            while (sleepLeftMs > 0) { delay(1000); sleepLeftMs -= 1000 }
            controller?.pause()
        }
    }

    fun toggleFav(s: Song) {
        favorites = if (s.id in favorites) favorites - s.id else favorites + s.id
        prefs.saveFavorites(favorites)
    }
    fun createPlaylist(name: String, first: Song? = null) {
        val n = name.trim(); if (n.isEmpty() || n in playlists) return
        playlists = playlists + (n to listOfNotNull(first?.id)); prefs.savePlaylists(playlists)
    }
    fun addToPlaylist(name: String, s: Song) {
        val l = playlists[name] ?: return
        if (s.id !in l) { playlists = playlists + (name to (l + s.id)); prefs.savePlaylists(playlists) }
    }
    fun removeFromPlaylist(name: String, s: Song) {
        playlists = playlists + (name to (playlists[name].orEmpty() - s.id)); prefs.savePlaylists(playlists)
    }
    fun deletePlaylist(name: String) { playlists = playlists - name; prefs.savePlaylists(playlists) }

    override fun onCleared() { controller?.release(); super.onCleared() }
}
