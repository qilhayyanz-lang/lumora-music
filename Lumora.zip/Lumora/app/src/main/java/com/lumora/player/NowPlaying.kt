@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package com.lumora.player

import android.content.Intent
import android.media.audiofx.AudioEffect
import android.widget.Toast
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import androidx.media3.common.Player
import androidx.palette.graphics.Palette
import coil.imageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun NowPlaying(vm: PlayerViewModel, onClose: () -> Unit) {
    val s = vm.current ?: return
    val ctx = LocalContext.current
    val primary = MaterialTheme.colorScheme.primary

    // Warna aksen dinamis dari cover album
    val accentRaw by produceState(primary, s.id) {
        val req = ImageRequest.Builder(ctx).data(s).allowHardware(false).size(200).build()
        val bmp = (ctx.imageLoader.execute(req) as? SuccessResult)?.drawable?.toBitmap()
        if (bmp != null) {
            val p = withContext(Dispatchers.Default) { Palette.from(bmp).generate() }
            (p.vibrantSwatch ?: p.dominantSwatch)?.let { value = Color(it.rgb) }
        }
    }
    val accent by animateColorAsState(accentRaw, label = "accent")
    val artScale by animateFloatAsState(if (vm.isPlaying) 1f else .9f, label = "scale")

    var drag by remember { mutableStateOf<Float?>(null) }
    var showQueue by remember { mutableStateOf(false) }
    var showSpeed by remember { mutableStateOf(false) }
    var showSleep by remember { mutableStateOf(false) }
    val fav = s.id in vm.favorites

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(accent.copy(alpha = .6f), Bg, Bg)))) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClose) { Icon(Icons.Rounded.KeyboardArrowDown, "Tutup", Modifier.size(32.dp)) }
                Text("Sedang diputar", Modifier.weight(1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelLarge, color = Color.White.copy(alpha = .7f))
                Spacer(Modifier.size(48.dp))
            }
            Spacer(Modifier.weight(1f))
            Art(s, Modifier.fillMaxWidth().aspectRatio(1f).scale(artScale).shadow(24.dp, RoundedCornerShape(28.dp), spotColor = accent), RoundedCornerShape(28.dp))
            Spacer(Modifier.weight(1f))

            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(s.title, Modifier.basicMarquee(), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, maxLines = 1)
                    Text(s.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Color.White.copy(alpha = .7f))
                }
                IconButton({ vm.toggleFav(s) }) {
                    Icon(if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, "Favorit", Modifier.size(28.dp), tint = if (fav) accent else Color.White)
                }
            }

            val max = vm.duration.coerceAtLeast(1L).toFloat()
            Slider(
                value = (drag ?: vm.position.toFloat()).coerceIn(0f, max),
                onValueChange = { drag = it },
                onValueChangeFinished = { drag?.let { vm.seekTo(it.toLong()) }; drag = null },
                valueRange = 0f..max,
                colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = accent, inactiveTrackColor = Color.White.copy(alpha = .2f)),
            )
            Row(Modifier.fillMaxWidth()) {
                Text(fmt((drag ?: vm.position.toFloat()).toLong()), style = MaterialTheme.typography.labelMedium, color = Color.White.copy(alpha = .7f))
                Spacer(Modifier.weight(1f))
                Text(fmt(vm.duration), style = MaterialTheme.typography.labelMedium, color = Color.White.copy(alpha = .7f))
            }

            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                IconButton({ vm.toggleShuffle() }) { Icon(Icons.Rounded.Shuffle, "Acak", tint = if (vm.shuffle) accent else Color.White.copy(alpha = .6f)) }
                IconButton({ vm.prev() }, Modifier.size(56.dp)) { Icon(Icons.Rounded.SkipPrevious, "Sebelumnya", Modifier.size(38.dp)) }
                FilledIconButton({ vm.togglePlay() }, Modifier.size(76.dp), colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color.White, contentColor = Color.Black)) {
                    Icon(if (vm.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, "Putar/Jeda", Modifier.size(42.dp))
                }
                IconButton({ vm.next() }, Modifier.size(56.dp)) { Icon(Icons.Rounded.SkipNext, "Berikutnya", Modifier.size(38.dp)) }
                IconButton({ vm.cycleRepeat() }) {
                    Icon(if (vm.repeat == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat, "Ulangi",
                        tint = if (vm.repeat != Player.REPEAT_MODE_OFF) accent else Color.White.copy(alpha = .6f))
                }
            }

            Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                TextButton({ showSpeed = true }) { Icon(Icons.Rounded.Speed, null); Spacer(Modifier.width(4.dp)); Text("${vm.speed}x") }
                TextButton({ showSleep = true }) {
                    Icon(Icons.Rounded.Timer, null); Spacer(Modifier.width(4.dp))
                    Text(if (vm.sleepLeftMs > 0) fmt(vm.sleepLeftMs) else "Timer")
                }
                TextButton({ showQueue = true }) { Icon(Icons.Rounded.QueueMusic, null); Spacer(Modifier.width(4.dp)); Text("Antrean") }
                TextButton({
                    try {
                        ctx.startActivity(Intent(AudioEffect.ACTION_DISPLAY_AUDIO_EFFECT_CONTROL_PANEL)
                            .putExtra(AudioEffect.EXTRA_PACKAGE_NAME, ctx.packageName)
                            .putExtra(AudioEffect.EXTRA_CONTENT_TYPE, AudioEffect.CONTENT_TYPE_MUSIC))
                    } catch (e: Exception) { Toast.makeText(ctx, "Equalizer sistem tidak tersedia", Toast.LENGTH_SHORT).show() }
                }) { Icon(Icons.Rounded.Equalizer, null); Spacer(Modifier.width(4.dp)); Text("EQ") }
            }
        }
    }

    if (showSpeed) AlertDialog({ showSpeed = false }, title = { Text("Kecepatan putar") },
        text = { Column { listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).forEach { v ->
            TextButton({ vm.setSpeed(v); showSpeed = false }) { Text("${v}x", color = if (v == vm.speed) accent else Color.Unspecified) } } } },
        confirmButton = {})

    if (showSleep) AlertDialog({ showSleep = false }, title = { Text("Sleep timer") },
        text = { Column { listOf(0, 5, 10, 15, 30, 45, 60).forEach { m ->
            TextButton({ vm.setSleep(m); showSleep = false }) { Text(if (m == 0) "Matikan" else "$m menit") } } } },
        confirmButton = {})

    if (showQueue) ModalBottomSheet({ showQueue = false }, containerColor = MaterialTheme.colorScheme.surface) {
        Text("Antrean (${vm.queue.size})", Modifier.padding(horizontal = 20.dp, vertical = 8.dp), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        LazyColumn(contentPadding = PaddingValues(bottom = 32.dp)) {
            itemsIndexed(vm.queue) { i, q ->
                val cur = q.id == s.id
                Row(Modifier.fillMaxWidth().clickable { vm.skipTo(i) }.padding(16.dp, 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Art(q, Modifier.size(44.dp), RoundedCornerShape(10.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(q.title, maxLines = 1, overflow = TextOverflow.Ellipsis, color = if (cur) accent else MaterialTheme.colorScheme.onSurface)
                        Text(q.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton({ vm.removeFromQueue(i) }) { Icon(Icons.Rounded.Close, "Hapus") }
                }
            }
        }
    }
}
