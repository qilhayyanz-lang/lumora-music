# Lumora — pemutar musik lokal

Kotlin + Jetpack Compose + Media3. Min Android 10 (API 29).

## Cara build APK
1. Install Android Studio (Koala/Ladybug atau lebih baru), JDK 17.
2. File > Open > pilih folder `Lumora`, tunggu Gradle sync.
3. Colok HP / emulator lalu Run, atau: Build > Build APK(s).
   APK ada di `app/build/outputs/apk/debug/`.

## Fitur
- Scan otomatis semua musik di perangkat (MediaStore)
- Tab Lagu / Album / Artis / Playlist / Favorit, pencarian, sortir
- Now Playing dengan warna aksen dinamis dari cover album
- Putar di background + kontrol di notifikasi & lock screen (MediaSession)
- Shuffle, repeat (off/all/one), antrean (putar berikutnya, tambah, hapus)
- Playlist & favorit (disimpan lokal), sleep timer, kecepatan putar, equalizer sistem
